import numpy as np
import data_loader
import module

'''Implement mini-batch SGD here'''
