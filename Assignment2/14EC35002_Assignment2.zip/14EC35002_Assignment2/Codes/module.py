import numpy as np

class NN(object):
    def __init__(self):
        pass
    def forward(self):
        pass
    def backward(self):
        pass
